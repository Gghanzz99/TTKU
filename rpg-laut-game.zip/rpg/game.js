let player = {
  name: '',
  x: 1,
  y: 1,
  hp: 100,
  exp: 0,
  level: 1,
  inventory: [],
};

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const cellSize = 50;
const mapSize = 10;
let enemies = [
  { x: 3, y: 3, type: 'minion', hp: 30 },
  { x: 6, y: 6, type: 'minion', hp: 30 },
  { x: 8, y: 8, type: 'boss', hp: 100 },
];

function startGame() {
  const name = document.getElementById('nameInput').value.trim();
  if (!name) return alert("Masukkan nama karakter!");
  player.name = name;

  // Tampilkan UI
  document.getElementById('start-screen').style.display = 'none';
  document.getElementById('game-ui').style.display = 'block';

  loadGame();
  drawMap();
  updateStatus();
  window.addEventListener('keydown', movePlayer);
}

function drawMap() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Gambar grid
  for (let y = 0; y < mapSize; y++) {
    for (let x = 0; x < mapSize; x++) {
      ctx.strokeStyle = '#fff';
      ctx.strokeRect(x * cellSize, y * cellSize, cellSize, cellSize);
    }
  }

  // Gambar musuh
  enemies.forEach(e => {
    ctx.fillStyle = e.type === 'boss' ? 'purple' : 'red';
    ctx.fillRect(e.x * cellSize + 10, e.y * cellSize + 10, 30, 30);
  });

  // Gambar player
  ctx.fillStyle = 'lime';
  ctx.fillRect(player.x * cellSize + 5, player.y * cellSize + 5, 40, 40);
}

function movePlayer(e) {
  if (e.key === 'ArrowUp' && player.y > 0) player.y--;
  if (e.key === 'ArrowDown' && player.y < mapSize - 1) player.y++;
  if (e.key === 'ArrowLeft' && player.x > 0) player.x--;
  if (e.key === 'ArrowRight' && player.x < mapSize - 1) player.x++;

  checkBattle();
  drawMap();
  updateStatus();
}

function checkBattle() {
  const enemy = enemies.find(e => e.x === player.x && e.y === player.y);
  if (enemy) {
    const damage = enemy.type === 'boss' ? 30 : 15;
    const reward = enemy.type === 'boss' ? 100 : 20;
    const item = enemy.type === 'boss' ? 'Harta Karun Laut' : 'Potion';

    player.hp -= damage;
    enemy.hp -= 50;

    log(`⚔️ Bertarung dengan ${enemy.type}! -${damage} HP`);

    if (enemy.hp <= 0) {
      enemies = enemies.filter(e => e !== enemy);
      player.exp += reward;
      player.inventory.push(item);
      log(`✅ Musuh dikalahkan! EXP +${reward}, Dapat item: ${item}`);
    }

    if (player.hp <= 0) {
      log("💀 Kamu kalah! Game over!");
      window.removeEventListener('keydown', movePlayer);
    }

    levelUp();
  }
}

function levelUp() {
  if (player.exp >= 100) {
    player.level++;
    player.exp = 0;
    player.hp = 100;
    log(`🎉 Level up! Sekarang level ${player.level}`);
  }
}

function updateStatus() {
  document.getElementById('status-bar').textContent =
    `🧍 ${player.name} | ❤️ HP: ${player.hp} | ⭐ EXP: ${player.exp} | 🆙 Level: ${player.level} | 🎒 ${player.inventory.length} item`;
}

function log(text) {
  document.getElementById('log').textContent = text;
}

function saveGame() {
  localStorage.setItem('rpg-save', JSON.stringify(player));
  log("💾 Game disimpan!");
}

function loadGame() {
  const data = localStorage.getItem('rpg-save');
  if (data) {
    player = JSON.parse(data);
    log("📦 Game dimuat dari penyimpanan.");
  }
}